import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

public class GameScene extends JPanel implements KeyListener {
    public static final int FAST_GAME=10;
    public static final int SLOW_GAME=100;
    private Bird player;
    private ArrayList<Obstacle> UpperObstacle;
    private ArrayList<Obstacle> BottomObstacle;
    public GameScene(int x, int y, int width, int height){
        this.setBounds(x,y,width,height);
        this.setBackground(Color.cyan);
        this.player=new Bird(Main.WINDOW_HEIGHT/2,60,60,Color.RED);
        this.BottomObstacle=new ArrayList<>();
        this.UpperObstacle=new ArrayList<>();
        this.mainGameLoop();
        this.setDoubleBuffered(true);
        this.CreateObstacle();
        this.RemoveObstacle();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.player.paint(g);
        for (int i=0; i<UpperObstacle.size() && i<BottomObstacle.size(); i++) {
            this.UpperObstacle.get(i).paint(g);
            this.BottomObstacle.get(i).paint(g);
        }

    }

    private void mainGameLoop() {

        new Thread(() -> {
            while (player.inBounds(player)) {
                CreateObstacle();
                RemoveObstacle();
                player.gravity();
                repaint();
                try {
                    Thread.sleep(FAST_GAME);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void CreateObstacle(){
        Random random=new Random();
        int BottomY=random.nextInt((int) (Main.WINDOW_HEIGHT/2-this.player.getHeight()));
        int UpperHeight=(int) (Main.WINDOW_HEIGHT-BottomY-this.player.getHeight());
         Obstacle upper=new Obstacle(0,UpperHeight);
         Obstacle bottom=new Obstacle(BottomY,BottomY);

        if ((this.UpperObstacle.isEmpty()&&this.BottomObstacle.isEmpty())||
                (this.UpperObstacle.get(0).getX()==500 && this.BottomObstacle.get(0).getX()==500)){
            this.UpperObstacle.add(upper);
            this.BottomObstacle.add(bottom);
        }
    }
    public void RemoveObstacle(){
        if (UpperObstacle.get(0).getX()==0 && BottomObstacle.get(0).getX()==0){
            UpperObstacle.remove(0);
            BottomObstacle.remove(0);
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_SPACE){
            player.fly();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
